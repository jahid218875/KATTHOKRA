</div>

<!-- footer  -->


</div>
</div>
<script src="<?php echo e(asset('admin/js/bootstrap.js')); ?>"></script>
<script src="<?php echo e(asset('admin/js/app.js')); ?>"></script>

<script src="<?php echo e(asset('admin/js/jquery.min.js')); ?>"></script>
<script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
<script src="<?php echo e(asset('admin/js/datatables.js')); ?>"></script>

<!-- Need: Apexcharts -->





<?php echo $__env->yieldContent('scripts'); ?>

</body>

</html><?php /**PATH D:\laragon\www\KATTHOKRA\resources\views/admin/layouts/footer.blade.php ENDPATH**/ ?>