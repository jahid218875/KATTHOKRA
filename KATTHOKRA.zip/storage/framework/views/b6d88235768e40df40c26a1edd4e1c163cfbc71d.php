
<?php $__env->startSection('content'); ?>

<!-- main section  -->

<section class="mb-5 container-fluid">
    <?php if(request()->path() == 'group/science'): ?>
    <h1 class="text-center my-5 fw-bold">বিজ্ঞান</h1>
    <?php $group = 'Science'; ?>
    <?php elseif(request()->path() == 'group/humanities'): ?>
    <h1 class="text-center my-5 fw-bold">মানবিক</h1>
    <?php $group = 'Humanities'; ?>
    <?php elseif(request()->path() == 'group/commerce'): ?>
    <h1 class="text-center my-5 fw-bold">ব্যবসায় শিক্ষা</h1>
    <?php $group = 'Commerce'; ?>

    <?php endif; ?>
    <div class="row">
        <?php $__currentLoopData = $subject; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $subject_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-3">
            <div class="card shadow my-3 border-0 mx-auto card-hover" style="width: 18rem;">
                <a href="<?php echo e(route('reader', ['name' => $group, 'subject' => $subject_list->subject_name])); ?>">
                    <img src="<?php echo e(asset('uploads/' . $subject_list->subject_image)); ?>" class="card-img-top" alt="...">
                </a>
                

            </div>
        </div>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('visitor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\KATTHOKRA\resources\views/visitor/group.blade.php ENDPATH**/ ?>