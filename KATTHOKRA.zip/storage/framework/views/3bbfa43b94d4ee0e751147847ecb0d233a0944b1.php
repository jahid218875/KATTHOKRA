

<?php $__env->startSection('content'); ?>
<div id="main">
    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    
                </div>
                <div class="col-12 col-md-6 order-md-2 order-first">
                    <nav aria-label="breadcrumb" class="breadcrumb-header float-start float-lg-end">
                        <ol class="breadcrumb">
                            <li class="breadcrumb-item"><a href="index.html">Dashboard</a></li>
                            <li class="breadcrumb-item active" aria-current="page">Form Layout</li>
                        </ol>
                    </nav>
                </div>
            </div>
        </div>




        <!-- // Basic multiple Column Form section start -->

        <section id="multiple-column-form">
            <div class="row match-height">


                <?php if(session('success')): ?>
                <script>
                    Swal.fire(
                    'Good job!',
                    '<?php echo e(session('success')); ?>',
                    'success'
                    )
                </script>
                <?php elseif(session('error')): ?>
                <script>
                    Swal.fire(
                    'Ooops....!',
                    '<?php echo e(session('error')); ?>',
                    'error'
                    )
                </script>
                <?php endif; ?>

                <?php if($errors->any()): ?>
                <div class="alert alert-danger">
                    <ul class="list-unstyled">
                        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li><?php echo e($error); ?></li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ul>
                </div>
                <?php endif; ?>


                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h4 class="card-title">HSC & Admission Content Add</h4>
                        </div>
                        <div class="card-content">
                            <div class="card-body">
                                <form class="form" action="<?php echo e(route('admin.hsc_content_update', $content->id)); ?>"
                                    method="post" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <div class="row">
                                        <div class="col-12">
                                            <h6>Subject Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="subject" name="subject_id" required>
                                                    <option value="<?php echo e($content->subject_id); ?>">
                                                        <?php echo e($content->getSubject->subject_name); ?></option>
                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12">
                                            <h6>Paper Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="paper" name="paper_id" required>
                                                    <option value="<?php echo e($content->paper_id); ?>">
                                                        <?php echo e($content->getPaper->paper_name); ?></option>

                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12">
                                            <h6>Chapter Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="chapter" name="chapter_id" required>
                                                    <option value="<?php echo e($content->chapter_id); ?>">
                                                        <?php echo e($content->getChapter->chapter_name); ?></option>
                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12">
                                            <h6>Type Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="type" name="type_id" required>
                                                    <option value="<?php echo e($content->type_id); ?>">
                                                        <?php echo e($content->getType->type_name); ?></option>

                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Page 1</h4>
                                                </div>
                                                <div class="card-body">
                                                    <textarea name="editor1" id="editor1" cols="30"
                                                        rows="10"><?php echo e($content->editor1); ?></textarea>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Page 2</h4>
                                                </div>
                                                <div class="card-body">
                                                    <textarea name="editor2" id="editor2" cols="30"
                                                        rows="10"><?php echo e($content->editor2); ?></textarea>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Page 3</h4>
                                                </div>
                                                <div class="card-body">
                                                    <textarea name="editor3" id="editor3" cols="30"
                                                        rows="10"><?php echo e($content->editor3); ?></textarea>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Page 4</h4>
                                                </div>
                                                <div class="card-body">
                                                    <textarea name="editor4" id="editor4" cols="30"
                                                        rows="10"><?php echo e($content->editor4); ?></textarea>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="card">
                                                <div class="card-header">
                                                    <h4 class="card-title">Page 5</h4>
                                                </div>
                                                <div class="card-body">
                                                    <textarea name="editor5" id="editor5" cols="30"
                                                        rows="10"><?php echo e($content->editor5); ?></textarea>

                                                    
                                                </div>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <h6>Course Type Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="course_type" name="course_type"
                                                    required>
                                                    <option <?php echo e($content->course_type == 'Free' ? 'selected' : ''); ?>>Free
                                                    </option>
                                                    <option <?php echo e($content->course_type == 'Premium' ? 'selected' :
                                                        ''); ?>>Premium
                                                    </option>

                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12">
                                            <h6>Status Select</h6>
                                            <fieldset class="form-group">
                                                <select class="form-select" id="status" name="status" required>
                                                    
                                                    <option <?php echo e($content->status == 'pending' ? 'selected' : ''); ?>>pending
                                                    </option>
                                                    <option <?php echo e($content->status == 'active' ? 'selected' : ''); ?>>active
                                                    </option>

                                                </select>
                                            </fieldset>
                                        </div>
                                        <div class="col-12 d-flex justify-content-end">
                                            <button type="submit" class="btn btn-success me-1 mb-1">Update</button>
                                        </div>
                                    </div>
                                </form>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <!-- // Basic multiple Column Form section end -->


    </div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('scripts'); ?>

<script src="https://cdn.ckeditor.com/4.19.1/standard/ckeditor.js"></script>


<script>
    // CK Editor 
CKEDITOR.replace( 'editor1' );
CKEDITOR.replace( 'editor2' );
CKEDITOR.replace( 'editor3' );
CKEDITOR.replace( 'editor4' );
CKEDITOR.replace( 'editor5' );

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\KATTHOKRA\resources\views/admin/hsc-content-edit.blade.php ENDPATH**/ ?>