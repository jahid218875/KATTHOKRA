
<?php $__env->startSection('content'); ?>
<div>
    <div class="container-fluid">
        <div class="row">
            <div class="col-md-12 py-5">

                <?php if(session('success')): ?>
                <script>
                    Swal.fire(
                    'Good job!',
                    '<?php echo e(session('success')); ?>',
                    'success'
                    )
                </script>
                <?php elseif(session('error')): ?>
                <script>
                    Swal.fire(
                    'Ooops....!',
                    '<?php echo e(session('error')); ?>',
                    'error'
                    )
                </script>
                <?php endif; ?>

                <h5 class="text-center fw-bold py-5">ঘরে বসে পড়াশোনার সহজ সমাধান
                    
                    <?php if(session('success')): ?>
                    <div class="alert alert-success">
                        <?php echo e(session('success')); ?>

                    </div>
                    <?php endif; ?>
                </h5>
                

                <form class="mx-auto" method="post" action="<?php echo e(route('loginSubmit')); ?>" style="width: 400px">
                    <?php echo csrf_field(); ?>
                    <div class="mb-3 emails">
                        <label for="exampleInputEmail1" class="form-label fw-bold">মোবাইল নাম্বার/ইমেইল</label>
                        <input type="email" name="email" class="form-control py-3 login-input border-0" id="email"
                            aria-describedby="emailHelp" placeholder="017xxxxxxxx">
                        
                    </div>
                    <div class="otp"></div>
                    <div class="password"></div>
                    <div class="more"></div>

                    <button class="btn btn-success fw-bold py-3 mt-3 login" style="width: 100%;"><i
                            class="fa-solid fa-arrow-right-to-bracket me-2"></i> এগিয়ে যান </button>
                </form>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>




<?php $__env->startSection('scripts'); ?>
<script>
    $('.login').click(function (e) {
	e.preventDefault();

    console.log($('#email').val())
    console.log($('#otpText').val())
    console.log($('#password').val())


    if(
        $('#email').val() !== undefined && 
        $('#password').val() !== undefined
    ){
        $('form').submit();   
    }


    if(
        $('#email').val() !== undefined && 
        $('#otpText').val() !== undefined && 
        $('#password').val() !== undefined
    ){
        //ajax
        $('form').submit();   
    }else if(
        $('#email').val() !== '' && 
        $('#otpText').val() !== undefined && 
        $('#password').val() === undefined
    ){
        //ajax
        $.ajax({
            url: "<?php echo e(route('loginSubmit')); ?>",
            type: 'POST',
            data: {
                '_token': $('input[name=_token]').val(),
                'email': $('#email').val(),
                'otp': $('#otpText').val(),
            },
            success: function (data) {
                if (data.status == 'set passsword') {
                    $('.password').html(`<div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label fw-bold">পাসওয়ার্ড</label>
                        <input type="password" name="password" class="form-control py-3 login-input border-0"
                            id="password" required>
                    </div>`);
                } else {
                    Swal.fire(
                    'Ooops....!',
                    'Invalid Otp Code',
                    'error'
                    )
                }
            }
        })        

    }else if($('#email').val() !== ''){
        //ajax
        $.ajax({
            url: "<?php echo e(route('loginSubmit')); ?>",
            type: 'POST',
            data: {
                '_token': $('input[name=_token]').val(),
                'email': $('#email').val(),
            },
            success: function (data) {
                if (data.status == 'otp') {
                    $('.otp').html(`<div class="mb-3">
                        <label for="otpText" class="form-label fw-bold">ফোনে পাঠানো OTP নিচে লিখুন
                        </label>
                        <input type="number" name="otp" class="form-control  py-3 login-input border-0" id="otpText"
                            aria-describedby="otplHelp" required>
                        <div id="otplHelp" class="form-text">আপনি কোডটি পাননি? <a href="#">আবার পাঠান</a></div>
                    </div>`);
                }else{
                    $('.password').html(`<div class="mb-3">
                        <label for="exampleInputPassword1" class="form-label fw-bold">পাসওয়ার্ড</label>
                        <input type="password" name="password" class="form-control py-3 login-input border-0"
                            id="password" required>
                    </div>`);
                }
            }
        })
    }
})

</script>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('visitor.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\KATTHOKRA\resources\views/visitor/login.blade.php ENDPATH**/ ?>