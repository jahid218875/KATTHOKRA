

<?php $__env->startSection('content'); ?>

<div id="main">
    <header class="mb-3">
        <a href="#" class="burger-btn d-block d-xl-none">
            <i class="bi bi-justify fs-3"></i>
        </a>
    </header>

    <?php if(session('success')): ?>
    <script>
        Swal.fire(
        'Good job!',
        '<?php echo e(session('success')); ?>',
        'success'
        )
    </script>
    <?php elseif(session('error')): ?>
    <script>
        Swal.fire(
        'Ooops....!',
        '<?php echo e(session('error')); ?>',
        'error'
        )
    </script>
    <?php endif; ?>

    <div class="page-heading">
        <div class="page-title">
            <div class="row">
                <div class="col-12 col-md-6 order-md-1 order-last">
                    <h3>Hsc and Admission Content List</h3>
                </div>
            </div>
        </div>

        <!-- Basic Tables start -->
        <section class="section mt-5">
            <div class="card">
                <div class="card-body">
                    <table class="table" id="table1">
                        <thead>
                            <tr>
                                <th>Subject Name</th>
                                <th>Paper Name</th>
                                <th>Chapter Name</th>
                                <th>Type</th>
                                <th>Status</th>
                                <th class="text-center">Action</th>
                            </tr>
                        </thead>
                        <tbody>

                            <?php $__currentLoopData = $hsc_content; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hsc_content_list): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($hsc_content_list->getSubject->subject_name); ?></td>
                                <td><?php echo e($hsc_content_list->getPaper->paper_name); ?></td>
                                <td><?php echo e($hsc_content_list->getChapter->chapter_name); ?></td>
                                <td><?php echo e($hsc_content_list->getType->type_name); ?></td>
                                <td><?php echo e($hsc_content_list->status); ?></td>
                                <td>
                                    <a href="<?php echo e(route('admin.hsc_content_edit', $hsc_content_list->id)); ?>"
                                        onclick="return confirm('are you sure?')" class="badge bg-success">Edit</a>
                                    <a href="<?php echo e(route('admin.hsc_content_delete', $hsc_content_list->id)); ?>"
                                        onclick="return confirm('are you sure?')" class="badge bg-danger">Delete</a>
                                </td>
                            </tr>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                        </tbody>
                    </table>
                </div>
            </div>
        </section>
        <!-- Basic Tables end -->
    </div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin.layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\KATTHOKRA\resources\views/admin/admin-hsc-content-list.blade.php ENDPATH**/ ?>