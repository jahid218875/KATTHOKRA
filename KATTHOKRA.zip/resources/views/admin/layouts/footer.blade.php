</div>

<!-- footer  -->


</div>
</div>
<script src="{{asset('admin/js/bootstrap.js')}}"></script>
<script src="{{asset('admin/js/app.js')}}"></script>

<script src="{{asset('admin/js/jquery.min.js')}}"></script>
<script src="https://cdn.datatables.net/v/bs5/dt-1.12.1/datatables.min.js"></script>
<script src="{{asset('admin/js/datatables.js')}}"></script>

<!-- Need: Apexcharts -->
{{-- <script src="{{asset('admin/js/apexcharts.min.js')}}"></script> --}}
{{-- <script src="{{asset('admin/js/dashboard.js')}}"></script> --}}



@yield('scripts')

</body>

</html>