@include('visitor.layouts.header')
@yield('content')
@include('visitor.layouts.footer')